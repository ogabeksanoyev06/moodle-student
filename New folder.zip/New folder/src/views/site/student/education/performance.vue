<template>
  <div></div>
</template>

<script>
export default {
  name: "EducationPerformance",
};
</script>

<style></style>
