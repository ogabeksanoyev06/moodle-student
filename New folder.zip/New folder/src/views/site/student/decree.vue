<template>
  <div></div>
</template>
<script>
export default {
  name: "AppDecree",
};
</script>
