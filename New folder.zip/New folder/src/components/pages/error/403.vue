<template>
  <div>403</div>
</template>

<script>
export default {
  name: "error-403",
};
</script>

<style lang="scss" scoped></style>
