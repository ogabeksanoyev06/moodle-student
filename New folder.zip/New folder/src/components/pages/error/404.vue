<template>
  <div>404</div>
</template>

<script>
export default {
  name: "error-404",
};
</script>

<style lang="scss" scoped></style>
