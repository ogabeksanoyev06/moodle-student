<template>
  <div>500</div>
</template>

<script>
export default {
  name: "error-500",
};
</script>

<style lang="scss" scoped></style>
